var config = {
    map: {
      "*": {
        "Magento_PageBuilder/js/content-type/products/appearance/carousel/widget":
          "CustomModule_PageBuilder/js/content-type/slider/appearance/default/product-carousel-override",
      },
    },
  };