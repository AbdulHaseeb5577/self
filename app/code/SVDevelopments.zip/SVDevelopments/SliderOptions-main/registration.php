<?php
/**
 * Module register
 *
 * Copyright © 2021 SVDevelopments. All rights reserved.
 *
 * @category Class
 * @package  SVDevelopments_SliderOptions
 * @author   SVDevelopments
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'SVDevelopments_SliderOptions-main', __DIR__);
